<?php 
include("config.php");
$fecha = $_POST['fecha'];
$hora= $_POST['hora'];

$sql = "INSERT INTO tb_horario_atencion(fecha,hora) 
VALUES('$fecha','$hora')";
if(mysqli_query($mysqli, $sql)){
    echo '<script language="javascript">';
	echo 'alert("Guardado");';
	echo 'window.location="horario_atencion.php";';
	echo '</script>';	
}
?>