<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
</head>
<body>
  
    <!-- Botón para cerrar sesión -->
    <form action="cerrarsesion.php" method="post">
        <button type="submit" name="cerrar_sesion">Cerrar Sesión</button>
    </form>
</body>
</html>