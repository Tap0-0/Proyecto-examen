
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Página Principal Dinámica</title>
  <style>
    body {
      font-family: 'Times New Roman', Times, serif, sans-serif;
      background-color: #f5e5ff; 
      color: #000; 
      margin: 0;
      padding: 0;
      background-image: url('perrito.jpg');
      background-size: cover; 
      background-position: center; 
      background-attachment: fixed; 
    }

    header {
      background-color: #ffc0cb; 
      color: #000; 
      padding: 10px;
      text-align: center;
    }

    section {
      margin: 20px;
      padding: 20px;
      background-color: rgba(236, 240, 241, 0.8); 
      border-radius: 5px;
    }

    footer {
      background-color: #34495e;
      color: #fff;
      padding: 10px;
      text-align: center;
      position: fixed;
      bottom: 0;
      width: 100%;
    }
  </style>
</head>
<body>

  <header>
    <h1 style="color: #ff69b4;">BIENVENIDOS A LA PELUQUERIA DOGSTYLE </h1> 
    <ul>
      <li><a href="inicio.php">Inicio</a></li>
    </ul>
  </header>
  

  <section>
    <?php
      
      $fecha_actual = date("Y-m-d H:i:s");
      echo "<p>¡Bienvenido a nuestra peluquería canina! 
      ¿Estás buscando un corte de pelo elegante para tu mascota? 
      ¡Estás en el lugar correcto!</p>";
      echo "<p>Contamos con un equipo de profesionales dedicados a mantener a tu perro con un aspecto fabuloso.</p>";
      echo "<p>¡Agenda tu cita hoy mismo!</p>";
      echo "<p> ¡Gracias por visitarnos!</p>";
    ?>
  
  <footer>
    <p>&copy; <?php echo date("Y"); ?> peluqueria canina</p>
  </footer>

</body>
</html>