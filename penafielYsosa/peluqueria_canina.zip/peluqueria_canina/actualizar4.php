<?php
//Conexion
include ("config.php");
$id = $_POST ['id'];
$nombre = $_POST ['nombre'];
$precio = $_POST ['precio'];
$sql = "UPDATE tb_servicio set  nombre= '$nombre', precio='$precio' where id_servicio=$id";
If(mysqli_query ($mysqli, $sql)) {
    echo '<script languaje ="javascript" >' ;
    echo 'window.location= "servicio.php"';
    echo '</script>' ;
    } 
?>