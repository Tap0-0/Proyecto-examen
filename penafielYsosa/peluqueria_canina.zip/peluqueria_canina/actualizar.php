<?php
//Conexion
include ("config.php");
$id = $_POST ['id'];
$nombre = $_POST ['nombre'];
$apellido = $_POST ['apellido'];
$cedula = $_POST ['cedula'];
$telefono= $_POST ['telefono'];
$direccion = $_POST ['direccion'];
$correo = $_POST ['correo'];
$sql = "UPDATE tb_cliente set  nombre= '$nombre', apellido='$apellido',cedula = '$cedula',telefono = '$telefono',direccion = '$direccion', correo='$correo' where id_cliente=$id";
If(mysqli_query ($mysqli, $sql)) {
    echo '<script languaje ="javascript" >' ;
    echo 'window.location= "cliente.php"';
    echo '</script>' ;
    } 
?>