<?php 
include("config.php");
$nombre = $_POST['nombre'];
$apellido = $_POST['apellido'];
$cedula = $_POST['cedula'];
$telefono = $_POST['telefono'];
$direccion= $_POST['direccion'];
$correo = $_POST['correo'];
$sql = "INSERT INTO tb_cliente(nombre,apellido,cedula,telefono,direccion,correo) 
VALUES('$nombre','$apellido','$cedula,'$telefono''$direccion','$correo')";
if(mysqli_query($mysqli, $sql)){
    echo '<script language="javascript">';
	echo 'alert("Guardado");';
	echo 'window.location="cliente.php";';
	echo '</script>';	
}
?>