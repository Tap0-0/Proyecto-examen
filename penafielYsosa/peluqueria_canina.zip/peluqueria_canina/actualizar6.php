<?php
//Conexion
include ("config.php");
$id = $_POST ['id'];
$fecha = $_POST ['fecha'];
$producto= $_POST ['producto'];
$cantidad = $_POST ['cantidad'];
$precio_total= $_POST ['precio_total'];

$sql = "UPDATE tb_venta set  fecha= '$fecha', producto='$producto',cantidad='$cantidad',precio_total='$precio_total'where id_venta=$id";
If(mysqli_query ($mysqli, $sql)) {
    echo '<script languaje ="javascript" >' ;
    echo 'window.location= "venta.php"';
    echo '</script>' ;
    } 
?>