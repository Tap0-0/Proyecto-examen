<?php
//Conexion
include ("config.php");
$id = $_POST ['id'];
$nombre = $_POST ['nombre'];
$descripcion = $_POST ['descripcion'];
$precio = $_POST ['precio']; 
$cantidad = $_POST ['cantidad'];
$sql = "UPDATE tb_producto set  nombre= '$nombre', descripcion= '$descripcion' ,precio='$precio', cantidad= '$cantidad' where id_producto=$id";
If(mysqli_query ($mysqli, $sql)) {
    echo '<script languaje ="javascript" >' ;
    echo 'window.location= "producto.php"';
    echo '</script>' ;
    } 
?>
