<?php
//Conexion
include ("config.php");
$id = $_POST ['id'];
$monto = $_POST ['monto'];
$fecha_pago= $_POST ['fecha_pago'];
$metodo_pago = $_POST ['metodo_pago'];

$sql = "UPDATE tb_pago set  monto= '$monto', fecha_pago='$fecha_pago',metodo_pago='$metodo_pago'where id_pago=$id";
if (mysqli_query ($mysqli, $sql)) {
    echo '<script languaje ="javascript">' ;
    echo 'window.location= "pago.php"';
    echo '</script>' ;
    } 
?>