<?php 
include("config.php");
$monto = $_POST['monto'];
$fecha_pago = $_POST['fecha_pago'];
$metodo_pago = $_POST['metodo_pago'];

$sql = "INSERT INTO tb_pago(monto,fecha_pago,metodo_pago) 
VALUES('$monto','$fecha_pago','$metodo_pago)";
if(mysqli_query($mysqli, $sql)){
    echo '<script language="javascript">';
	echo 'alert("Guardado");';
	echo 'window.location="pago.php";';
	echo '</script>';	
}
?>