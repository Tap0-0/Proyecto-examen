<?php 
include("config.php");
$id = $_GET['id'];
$sql ="UPDATE tb_venta SET estado = 0
WHERE id_venta= $id";
if(mysqli_query($mysqli, $sql)){
    echo '<script language="javascript">';
	echo 'window.location="venta.php";';
	echo '</script>';
	
}
?>