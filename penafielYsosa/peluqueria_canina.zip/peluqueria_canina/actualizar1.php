<?php
//Conexion
include ("config.php");
$id = $_POST ['id'];
$fecha = $_POST ['fecha'];
$hora = $_POST ['hora'];

$sql = "UPDATE tb_horario_atencion set  fecha= '$fecha', hora='$hora' where id_horario_atencion=$id";
If(mysqli_query ($mysqli, $sql)) {
    echo '<script languaje ="javascript" >' ;
    echo 'window.location= "horario_atencion.php"';
    echo '</script>' ;
    } 
?>