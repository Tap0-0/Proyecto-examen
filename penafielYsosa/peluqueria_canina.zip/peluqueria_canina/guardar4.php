<?php 
include("config.php");
$nombre = $_POST['nombre'];
$precio = $_POST['precio'];
$sql = "INSERT INTO tb_servicio(nombre,precio) 
VALUES('$nombre','$precio')";
if(mysqli_query($mysqli, $sql)){
    echo '<script language="javascript">';
	echo 'alert("Guardado");';
	echo 'window.location="servicio.php";';
	echo '</script>';	
}
?>