
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="css/mystyle5.css" />
  <title>PAGINA DE INICIO PRINCIPAL</title>

  <style>
    body {
      background-color: #ffc0cb;
      color: #222;
      font-family: sans-serif;
      margin: 0;
      background-image: url('perro1.jpg');
      background-size: cover;
      background-position: center;
      background-attachment: fixed;
    }

    button {
      font-size: 1.2rem; /* Medium font size */
      padding: 10px 20px;
      border: none;
      background-color: white; /* White background */
      color: black; /* Black text */
      cursor: pointer;
      text-decoration: none;
      transition: background-color 0.2s ease-in-out;
      display: inline-block; /* Display buttons side-by-side */
      margin-right: 10px; /* Add spacing between buttons */
    }

    button:hover {
      background-color: #f55; /* Change hover effect color (optional) */
    }

    div {
      text-align: left; /* Align buttons to the left */
      margin-bottom: 10px;
    }
  </style>
</head>
<body>

  <div>
    <a href="cliente.php"><button>CLIENTE</button></a>
    <a href="horario_antencion.php"><button>HORARIO_ATENCION</button></a>
    <a href="cita.php"><button>CITA</button></a>
    <a href="servicio.php"><button>SERVICIO</button></a>
    <a href="producto.php"><button>PRODUCTO</button></a>
    <a href="venta.php"><button>VENTA</button></a>
    <a href="pago.php"><button>PAGO</button></a>
   
  </div>

</body>
</html>