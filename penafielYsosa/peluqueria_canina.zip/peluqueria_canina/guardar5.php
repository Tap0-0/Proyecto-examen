<?php 
include("config.php");
$nombre = $_POST ['nombre'];
$descripcion = $_POST ['descripcion'];
$precio = $_POST ['precio']; 
$cantidad = $_POST ['cantidad'];
$sql = "INSERT INTO tb_producto(nombre,descripcion,precio,cantidad) 
VALUES('$nombre', '$descripcion','$precio', '$cantidad')";
if(mysqli_query($mysqli, $sql)){
    echo '<script language="javascript">';
	echo 'alert("Guardado");';
	echo 'window.location="producto.php";';
	echo '</script>';	
}
?>