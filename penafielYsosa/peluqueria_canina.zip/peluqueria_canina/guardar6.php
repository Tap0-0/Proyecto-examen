<?php 
include("config.php");
$fecha = $_POST['fecha'];
$producto= $_POST['producto'];
$cantidad= $_POST['cantidad'];
$precio_total= $_POST['precio_total'];

$sql = "INSERT INTO tb_venta(fecha,producto,cantidad,cantidad,precio_total) 
VALUES('$fecha','$producto','$cantidad,'$precio_total')";
if(mysqli_query($mysqli, $sql)){
    echo '<script language="javascript">';
	echo 'alert("Guardado");';
	echo 'window.location="venta.php";';
	echo '</script>';	
}
?>