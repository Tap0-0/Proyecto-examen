<?php 
include("config.php");
$id = $_GET['id'];
$sql ="UPDATE tb_pago SET estado = 0
WHERE id_pago = $id";
if(mysqli_query($mysqli, $sql)){
    echo '<script language="javascript">';
	echo 'window.location="pago.php";';
	echo '</script>';
	
}
?>