<?php 
include("config.php");
$fecha = $_POST['fecha'];
$hora = $_POST['hora'];
$servicio = $_POST['servicio'];
$sql = "INSERT INTO tb_cita(fecha,hora,servicio) 
VALUES('$fecha','$hora','$servicio')";
if(mysqli_query($mysqli, $sql)){
    echo '<script language="javascript">';
	echo 'alert("Guardado");';
	echo 'window.location="cita.php";';
	echo '</script>';	
}
?>