<?php
//Conexion
include ("config
.php");
$id = $_POST ['id'];
$nombre = $_POST ['nombre'];
$clave = $_POST ['clave'];
$sql = "UPDATE tb_usuario set nombre = '$nombre', clave = '$clave' where id_usuario=$id";
If(mysqli_query ($mysqli, $sql)) {
    echo '<script languaje ="javascript" >' ;
    echo 'window.location= "usuario.php"';
    echo '</script>' ;
    } 
?>