<?php
//Conexion
include ("config.php");
$id = $_POST ['id'];
$fecha = $_POST ['fecha'];
$hora = $_POST ['hora'];
$servicio = $_POST ['servicio'];
$sql = "UPDATE tb_cita set  fecha= '$fecha', hora='$hora',servicio = '$servicio'  where id_cita=$id";
If(mysqli_query ($mysqli, $sql)) {
    echo '<script languaje ="javascript" >' ;
    echo 'window.location= "cita.php"';
    echo '</script>' ;
    } 
?>