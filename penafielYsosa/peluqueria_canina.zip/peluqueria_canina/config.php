<?php
//Configurar los parametros de conexion a la base de datos
$mysqli = new mysqli('localhost', 'root', '', 'bd_peluqueria_canina');

?>php
