<?php 
//seguridad de sessiones paginacion
session_start();
error_reporting(0);
$varsesion= $_SESSION['usuario'];
if($varsesion== null || $varsesion=''){
    header("location:index.php");
    die();
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/mystyle2.css" />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css">
    <style>
        body {
         
            background-size: cover;
            background-repeat: no-repeat;
        }
    </style>
    <title>Página Principal</title>
</head>
       
    <!-- Creamos un menu     -->
    <div class="icon-bar">
        <a href="cerrar_sesion.php"><i class="fa fa-sign-out" aria-hidden="true"></i>
        
    </div>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <div class="mensaje">
    <h1 class="animate__animated animate__backInLeft"> Bienvenido a la Sastreria</h1> 
    </div>
    

    <a href="alquiler.php"><button><H1>ALQUILER</H1></button></a>
    <a href="clientes.php"><button><H1>CLIENTES</H1></button></a>
    <a href="direcciones.php"><button><H1>DIRECCIONES</H1></button></a>
    <a href="inventario.php"><button><H1>INVENTARIO</H1></button></a>
    <a href="locales.php"><button><H1>LOCAL-ES</H1></button></a>
    <a href="detalles_pedidos.php"><button><H1>DETALLES DE PEDIDOS</H1></button></a>
    
    <a href="articulos_alquiler.php"><button><H1>ARTICULOS DE ALQUILER</H1></button></a>
    <a href="medidas_clientes.php"><button><H1>MEDIDAS DEL CLIENTE</H1></button></a>
    <a href="pedidos.php"><button><H1>PEDIDOS</H1></button></a>
    <a href="productos.php"><button><H1>PRODUCTOS</H1></button></a>
    <a href="transaccion.php"><button><H1>TRANSACCIONES</H1></button></a>
    
    <script src="./js/cambiar_fondo.js"></script>
</body>
</html>
