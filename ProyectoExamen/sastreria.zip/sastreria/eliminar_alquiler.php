 <?php

include("config.php");
$id = $_GET['id'];
$sql = "UPDATE tb_alquiler SET estado = 0 WHERE id = $id";

if(mysqli_query($mysqli, $sql)){
    echo'<script languaje ="javascript">';
    echo'window.location="alquiler.php"';
    echo'</script>';
}
?> 