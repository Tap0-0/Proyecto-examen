<?php 
include("config.php");
$tipo_material = $_POST['pecho'];
$descripcion = $_POST['cintura'];
$cantidad_disponible = $_POST['cadera'];
$precio_unitario = $_POST['longitudbrazo'];
$longitud_brazo = $_POST['longitudpiernas'];
$entrepiernas = $_POST['entrepiernas'];

$sql = "INSERT INTO tb_medidasclientes(pecho,cintura,cadera,longitudbrazo,longitudpiernas,entrepiernas) 
VALUES('$tipo_material','$descripcion','$cantidad_disponible','$precio_unitario','$longitud_brazo','$entrepiernas')";

if(mysqli_query($mysqli, $sql)){
    echo '<script language="javascript">';
	echo 'alert("Guardado");';
	echo 'window.location="medidas_clientes.php";';
	echo '</script>';	
}
?>