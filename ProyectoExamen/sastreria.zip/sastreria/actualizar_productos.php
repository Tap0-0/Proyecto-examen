<?php

include("config.php");
$id = $_POST['id'];
$NOMBRE = $_POST['descripcion'];
$APELLIDO = $_POST['tipo_prenda'];
$DIRECCION = $_POST['talla'];
$TELEFONO = $_POST['color'];
$CORREO = $_POST['material'];
$PRECIO = $_POST['precio'];
$sql = "UPDATE tb_productos SET descripcion = '$NOMBRE', tipo_prenda = '$APELLIDO', 
talla = '$DIRECCION', color='$TELEFONO', material='$CORREO', precio='$PRECIO' WHERE id = $id";
if(mysqli_query($mysqli, $sql)){
    echo'<script languaje ="javascript">';
    echo'window.location="productos.php"';
    echo'</script>';
}
?>