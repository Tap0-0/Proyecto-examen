// Definir una lista de imágenes de fondo
var fondos = ['2606.jpg', '12145.jpg', 'OBOSMJ0.jpg'];
var indice = 0;

// Función para cambiar el fondo
function cambiarFondo() {
    document.body.style.backgroundImage = 'url(' + fondos[indice] + ')';
    indice = (indice + 1) % fondos.length;
}

// Cambiar el fondo cada cierto intervalo de tiempo (por ejemplo, cada 5 segundos)
setInterval(cambiarFondo, 3000); // 5000 milisegundos = 5 segundos
