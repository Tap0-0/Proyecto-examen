<?php

include("config.php");
$id = $_POST['id'];
$CALLE = $_POST['calle'];
$DIRECCION = $_POST['direccion'];
$CODIGO_POSTAL = $_POST['codigo_postal'];
$PAIS = $_POST['pais'];

$sql = "UPDATE tb_clientes SET calle = '$CALLE', direccion = '$DIRECCION', codigo_postal = '$CODIGO_POSTAL', pais='$PAIS' WHERE id = $id";
if(mysqli_query($mysqli, $sql)){
    echo'<script languaje ="javascript">';
    echo'window.location="direcciones.php"';
    echo'</script>';
}
?>