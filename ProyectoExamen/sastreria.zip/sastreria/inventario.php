<?php
include("config.php");
//Hago el query con el select
$query = "SELECT * FROM tb_inventarios WHERE estado = 1 " ;
$result = mysqli_query($mysqli, $query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/mystyle1.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


    <title>Inventario</title>
</head>
<body>
    <!-- menu -->
    <div class="icon-bar">
      
        <a href="home.php"><i class="fa fa-home"></i></a>
        <a href="registro_inventario.php"><i class="fa fa-registered"></i></a>
        <a href="./reportes/fpdf/reporte_inventario.php" target="_blank" class="btn btn-succes"><i class="fa fa-file-pdf-o" aria-hidden="true"></i></a>
              
    </div>
    <h1>Inventario</h1>
    <hr>
    <div class="Container">
    <!-- Creo la tabla para presentar las areas de la base de datos  -->
    <?php
     echo "<table border='1'>
      <tr>
        <th>Codigo</th>
        <th>Tipo Del Material</th>
        <th>Descripcion</th>
        <th>Cantidad Disponible</th>
        <th>Precio por Unidad</th>
       
        <th>Actualizar</th>
        <th>Eliminar</th>
        
      </tr>";
      while ($row = mysqli_fetch_array($result)){
        //Recorro cada uno del array y lo voy presentando 
        echo "<tr>";
        echo "<td>". $row['id_inventario']."</td>";
        echo "<td>". $row['tipomaterial']. "</td>";
        echo "<td>". $row['descripcion']."</td>";
        echo "<td>". $row['cantidadisponible']. "</td>";
        echo "<td>". $row['preciounitario']."</td>";
  
        echo "<td><a href='editar_inventario.php?id=". $row['id_inventario']. "'><img src='./images/icons8-Edit-32.png' alt='Edit'></a></td>";
        echo "<td><a href='eliminar_inventario.php?id=". $row['id_inventario']. "'><img src='./images/icons8-Trash-32.png' alt='Delete'></a></td>";
        
        echo "</tr>";
      }
      echo "</table>";
      //Fin de la tabla

    ?>
</body>
</html>