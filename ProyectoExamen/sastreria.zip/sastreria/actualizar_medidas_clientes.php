<?php

include("config.php");
$id = $_POST['id'];
$tipo_material = $_POST['pecho'];
$descripcion = $_POST['cintura'];
$cantidad_disponible = $_POST['cadera'];
$precio_unitario = $_POST['longitudbrazo'];
$longitud_piernas = $_POST['longitudpiernas'];
$entrepiernas = $_POST['entrepiernas'];

$sql = "UPDATE tb_medidasclientes SET pecho = '$tipo_material',cintura = '$descripcion', cadera = '$cantidad_disponible',
  longitudbrazo='$precio_unitario', longitudpiernas='$longitud_piernas',
  entrepiernas='$entrepiernas' WHERE id_medidasclientes = $id";
if(mysqli_query($mysqli, $sql)){
    echo'<script languaje ="javascript">';
    echo'window.location="medidas_clientes.php"';
    echo'</script>';
}
?>