<?php
require('fpdf.php');


class PDF extends FPDF
{
// Cabecera de página
function Header()
{
    // Logo
    // $this->Image('logo.png',10,8,33);

    // Arial bold 15
    $this->SetFont('Arial','B',18);
    // Movernos a la derecha
    $this->Cell(60);
    // Título
    $this->Cell(150,10,'Reporte de Medidas del Cliente',0,0,'C');
    // Salto de línea
    $this->Ln(20);

    $this->Cell(60,10,'Descripcion',1,0,'C',0);
    $this->Cell(70,10,'Tipo de Prenda',1,0,'C',0);
    $this->Cell(30,10,'Talla',1,0,'C',0);
    $this->Cell(40,10,'Color',1,0,'C',0);
    $this->Cell(40,10,'Material',1,0,'C',0);
    $this->Cell(30,10,'Precio',1,1,'C',0);
   
}

// Pie de página
function Footer()
{
    // Posición: a 1,5 cm del final
    $this->SetY(-15);
    // Arial italic 8
    $this->SetFont('Arial','I',8);
    // Número de página
    $this->Cell(0,10,utf8_decode('Página ').$this->PageNo().'/{nb}',0,0,'C');
}

}

require 'cn.php';
$consulta = "SELECT *FROM tb_productos where estado=1";
$resultado = $mysqli->query($consulta);

$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage('H');
$pdf->SetFont('Arial','',16);

while($row = $resultado->fetch_assoc()){
    $pdf->Cell(60,10,$row['descripcion'],1,0,'C',0);
    $pdf->Cell(70,10,$row['tipo_prenda'],1,0,'C',0);
    $pdf->Cell(30,10,$row['talla'],1,0,'C',0);
    $pdf->Cell(40,10,$row['color'],1,0,'C',0);
    $pdf->Cell(40,10,$row['material'],1,0,'C',0);
    $pdf->Cell(30,10,$row['precio'],1,1,'C',0);
    
}



$pdf->Output();


?>