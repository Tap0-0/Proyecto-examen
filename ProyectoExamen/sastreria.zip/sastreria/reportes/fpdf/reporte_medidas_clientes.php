<?php
require('fpdf.php');


class PDF extends FPDF
{
// Cabecera de página
function Header()
{
    // Logo
    // $this->Image('logo.png',10,8,33);

    // Arial bold 15
    $this->SetFont('Arial','B',18);
    // Movernos a la derecha
    $this->Cell(60);
    // Título
    $this->Cell(150,10,'Reporte de Medidas del Cliente',0,0,'C');
    // Salto de línea
    $this->Ln(20);

    $this->Cell(30,10,'Pecho',1,0,'C',0);
    $this->Cell(30,10,'Cintura',1,0,'C',0);
    $this->Cell(30,10,'Cadera',1,0,'C',0);
    $this->Cell(60,10,'Long de Brazos',1,0,'C',0);
    $this->Cell(60,10,'Long de Piernas',1,0,'C',0);
    $this->Cell(60,10,'EntrePiernas',1,1,'C',0);
   
}

// Pie de página
function Footer()
{
    // Posición: a 1,5 cm del final
    $this->SetY(-15);
    // Arial italic 8
    $this->SetFont('Arial','I',8);
    // Número de página
    $this->Cell(0,10,utf8_decode('Página ').$this->PageNo().'/{nb}',0,0,'C');
}

}

require 'cn.php';
$consulta = "SELECT *FROM tb_medidasclientes where estado=1";
$resultado = $mysqli->query($consulta);

$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage('H');
$pdf->SetFont('Arial','',16);

while($row = $resultado->fetch_assoc()){
    $pdf->Cell(30,10,$row['pecho'],1,0,'C',0);
    $pdf->Cell(30,10,$row['cintura'],1,0,'C',0);
    $pdf->Cell(30,10,$row['cadera'],1,0,'C',0);
    $pdf->Cell(60,10,$row['longitudbrazo'],1,0,'C',0);
    $pdf->Cell(60,10,$row['longitudpiernas'],1,0,'C',0);
    $pdf->Cell(60,10,$row['entrepiernas'],1,1,'C',0);
    
}



$pdf->Output();


?>