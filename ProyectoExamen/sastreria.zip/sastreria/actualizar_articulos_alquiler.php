<?php

include("config.php");
$id = $_POST['id'];
$DESCRIPCION = $_POST['cantidad'];
$TALLA = $_POST['subtotal'];
$sql = "UPDATE tb_articulosalquiler SET descripcion = '$DESCRIPCION', talla = '$TALLA' WHERE id = $id";
if(mysqli_query($mysqli, $sql)){
    echo'<script languaje ="javascript">';
    echo'window.location="articulos_alquiler.php"';
    echo'</script>';
}
?>