<?php

include("config.php");
$id = $_POST['id'];
$fecha = $_POST['fecha'];
$tipo_transaccion= $_POST['tipotransaccion'];
$monto = $_POST['monto'];


$sql = "UPDATE tb_transicion SET fecha = '$fecha', tipotransaccion = '$tipo_transaccion', monto = '$monto' WHERE id_transaccion = $id";
if(mysqli_query($mysqli, $sql)){
    echo'<script languaje ="javascript">';
    echo'window.location="transaccion.php"';
    echo'</script>';
}
?>