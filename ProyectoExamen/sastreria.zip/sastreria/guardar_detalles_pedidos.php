<?php 
include("config.php");
$descripcion = $_POST['cantidad'];
$talla = $_POST['subtotal'];
$sql = "INSERT INTO tb_detallespedidos(cantidad,subtotal) 
VALUES('$descripcion','$talla')";

if(mysqli_query($mysqli, $sql)){
    echo '<script language="javascript">';
	echo 'alert("Guardado");';
	echo 'window.location="detalles_pedidos.php";';
	echo '</script>';	
}
?>