<?php
include("config.php");
$id = $_GET['id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/mystyle1.css" />
    <title>Actualizar</title>
</head>
<body>
    <!-- Creamos un menu     -->
    <div class="icon-bar">
        <a href="inicio.php"><i class="fa fa-home"></i></a>
        <a href="alquiler.php"><i class="fa fa-user"></i></a>
    </div>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <h2>Actualizar</h2>
    <hr />
    <form action="actualizar_alquiler.php" method="POST">
        <div class="container">
            <?php
            //preparamos consulta
            $result = mysqli_query($mysqli,"SELECT*FROM tb_alquiler WHERE id= $id");
                while($row= mysqli_fetch_array($result)){
                    echo "<input type='hidden' name='id' value='{$row['id']}' required>";
                    echo "<h2>Descripcion</h2>";
                    echo "<input type='text' name='descripcion' value='{$row ['descripcion']}' required>";
                    echo "<h2>Talla</h2>";
                    echo "<input type='text' name='talla' value='{$row ['talla']}' required>";
                    echo "<h2>Precio de Alquiler</h2>";
                    echo "<input type='text' name='precio_alquiler' value='{$row ['precio_alquiler']}' required>";
                   echo"<div class= 'clearfix'>";
                   echo"<button type = 'submit'class= 'signupbtn'>Actualizar </button>";
                   echo"</div>";
                    
                }
            ?>

        </div>
    </form>
</body>
</html>