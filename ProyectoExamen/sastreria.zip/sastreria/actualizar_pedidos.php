<?php

include("config.php");
$id = $_POST['id'];
$tipo_material = $_POST['fechapedido'];
$descripcion = $_POST['fechaentrega'];
$cantidad_disponible = $_POST['total'];

$sql = "UPDATE tb_pedidos SET fechapedido = '$tipo_material', fechaentrega= '$descripcion', total = '$cantidad_disponible' WHERE id = $id";
if(mysqli_query($mysqli, $sql)){
    echo'<script languaje ="javascript">';
    echo'window.location="pedidos.php"';
    echo'</script>';
}
?>