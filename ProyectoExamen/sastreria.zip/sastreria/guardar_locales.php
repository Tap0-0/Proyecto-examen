<?php 
include("config.php");
$tipo_material = $_POST['nombre'];
$descripcion = $_POST['telefono'];
$cantidad_disponible = $_POST['email'];

$sql = "INSERT INTO tb_local(nombre,telefono,email) 
VALUES('$tipo_material','$descripcion','$cantidad_disponible')";

if(mysqli_query($mysqli, $sql)){
    echo '<script language="javascript">';
	echo 'alert("Guardado");';
	echo 'window.location="locales.php";';
	echo '</script>';	
}
?>