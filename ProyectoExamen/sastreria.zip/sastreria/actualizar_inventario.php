<?php

include("config.php");
$id = $_POST['id'];
$tipo_material = $_POST['tipomaterial'];
$descripcion = $_POST['descripcion'];
$cantidad_disponible = $_POST['cantidadisponible'];
$precio_unitario = $_POST['preciounitario'];

$sql = "UPDATE tb_inventarios SET tipomaterial = '$tipo_material', descripcion = '$descripcion', cantidadisponible = '$cantidad_disponible', preciounitario='$precio_unitario' WHERE id_inventario = $id";
if(mysqli_query($mysqli, $sql)){
    echo'<script languaje ="javascript">';
    echo'window.location="direcciones.php"';
    echo'</script>';
}
?>