<?php

include("config.php");
$id = $_GET['id'];
$sql = "UPDATE tb_inventarios SET estado = 0 WHERE id_inventario = $id";

if(mysqli_query($mysqli, $sql)){
    echo'<script languaje ="javascript">';
    echo'window.location="inventario.php"';
    echo'</script>';
}
?>