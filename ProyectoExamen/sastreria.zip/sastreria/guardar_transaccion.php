<?php 
include("config.php");
$fecha = $_POST['fecha'];
$tipo_transaccion = $_POST['tipotransaccion'];
$monto = $_POST['monto'];

$sql = "INSERT INTO tb_transicion(fecha,tipotransaccion,monto) 
VALUES('$fecha','$tipo_transaccion','$monto')";

if(mysqli_query($mysqli, $sql)){
    echo '<script language="javascript">';
	echo 'alert("Guardado");';
	echo 'window.location="transaccion.php";';
	echo '</script>';	
}
?>