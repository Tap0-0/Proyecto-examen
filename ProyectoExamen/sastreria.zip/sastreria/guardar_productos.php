<?php 
include("config.php");
$nombre = $_POST['descripcion'];
$apellido = $_POST['tipo_prenda'];
$direccion = $_POST['talla'];
$telefono = $_POST['color'];
$correo = $_POST['material'];
$precio = $_POST['precio'];
$sql = "INSERT INTO tb_productos(descripcion,tipo_prenda,talla,color,material,precio) 
VALUES('$nombre','$apellido','$direccion','$telefono','$correo','$precio')";

if(mysqli_query($mysqli, $sql)){
    echo '<script language="javascript">';
	echo 'alert("Guardado");';
	echo 'window.location="productos.php";';
	echo '</script>';	
}
?>