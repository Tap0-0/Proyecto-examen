<?php

include("config.php");
$id = $_GET['id'];
$sql = "UPDATE tb_productos SET estado = 0 WHERE id = $id";

if(mysqli_query($mysqli, $sql)){
    echo'<script languaje ="javascript">';
    echo'window.location="productos.php"';
    echo'</script>';
}
?>