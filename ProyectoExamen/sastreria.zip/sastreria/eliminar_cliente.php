<?php

include("config.php");
$id = $_GET['id'];
$sql = "UPDATE tb_clientes SET estado = 0 WHERE id_clientes = $id";

if(mysqli_query($mysqli, $sql)){
    echo'<script languaje ="javascript">';
    echo'window.location="clientes.php"';
    echo'</script>';
}
?>