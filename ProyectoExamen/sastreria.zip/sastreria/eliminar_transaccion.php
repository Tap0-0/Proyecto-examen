<?php

include("config.php");
$id = $_GET['id'];
$sql = "UPDATE tb_transicion SET estado = 0 WHERE id_transaccion = $id";

if(mysqli_query($mysqli, $sql)){
    echo'<script languaje ="javascript">';
    echo'window.location="transaccion.php"';
    echo'</script>';
}
?>