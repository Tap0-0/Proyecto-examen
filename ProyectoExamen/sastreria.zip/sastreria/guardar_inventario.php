<?php 
include("config.php");
$tipo_material = $_POST['tipomaterial'];
$descripcion = $_POST['descripcion'];
$cantidad_disponible = $_POST['cantidadisponible'];
$precio_unitario = $_POST['preciounitario'];

$sql = "INSERT INTO tb_inventarios(tipomaterial,descripcion,cantidadisponible,preciounitario) 
VALUES('$tipo_material','$descripcion','$cantidad_disponible','$precio_unitario')";

if(mysqli_query($mysqli, $sql)){
    echo '<script language="javascript">';
	echo 'alert("Guardado");';
	echo 'window.location="inventario.php";';
	echo '</script>';	
}
?>