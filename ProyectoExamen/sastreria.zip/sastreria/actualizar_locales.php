<?php

include("config.php");
$id = $_POST['id'];
$tipo_material = $_POST['nombre'];
$descripcion = $_POST['telefono'];
$cantidad_disponible = $_POST['email'];

$sql = "UPDATE tb_local SET nombre = '$tipo_material', telefono = '$descripcion', email = '$cantidad_disponible' WHERE id = $id";
if(mysqli_query($mysqli, $sql)){
    echo'<script languaje ="javascript">';
    echo'window.location="locales.php"';
    echo'</script>';
}
?>