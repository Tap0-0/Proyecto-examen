<?php 
include("config.php");
$nombre = $_POST['nombre'];
$apellido = $_POST['apellido'];
$direccion = $_POST['direccion'];
$telefono = $_POST['telefono'];
$correo = $_POST['email'];
$sql = "INSERT INTO tb_clientes(nombre,apellido,direccion,telefono,email) 
VALUES('$nombre','$apellido','$direccion','$telefono','$correo')";

if(mysqli_query($mysqli, $sql)){
    echo '<script language="javascript">';
	echo 'alert("Guardado");';
	echo 'window.location="clientes.php";';
	echo '</script>';	
}
?>