<?php 
include("config.php");
$CALLE = $_POST['calle'];
$CIUDAD = $_POST['ciudad'];
$CODIGO_POSTAL = $_POST['codigo_postal'];
$PAIS = $_POST['pais'];

$sql = "INSERT INTO tb_direcciones(calle,ciudad,codigo_postal,pais) 
VALUES('$CALLE','$CIUDAD','$CODIGO_POSTAL','$PAIS')";

if(mysqli_query($mysqli, $sql)){
    echo '<script language="javascript">';
	echo 'alert("Guardado");';
	echo 'window.location="direcciones.php";';
	echo '</script>';	
}
?>