<?php

include("config.php");
$id = $_POST['id'];
$NOMBRE = $_POST['nombre'];
$APELLIDO = $_POST['apellido'];
$DIRECCION = $_POST['direccion'];
$TELEFONO = $_POST['telefono'];
$CORREO = $_POST['email'];
$sql = "UPDATE tb_clientes SET nombre = '$NOMBRE', apellido = '$APELLIDO', direccion = '$DIRECCION', telefono='$TELEFONO', email='$CORREO' WHERE id_clientes = $id";
if(mysqli_query($mysqli, $sql)){
    echo'<script languaje ="javascript">';
    echo'window.location="clientes.php"';
    echo'</script>';
}
?>