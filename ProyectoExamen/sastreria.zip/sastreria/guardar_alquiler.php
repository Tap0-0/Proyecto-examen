<?php 
include("config.php");
$descripcion = $_POST['descripcion'];
$talla = $_POST['talla'];
$precioalquiler = $_POST['precio_alquiler'];
$sql = "INSERT INTO tb_alquiler(descripcion,talla,precio_alquiler) 
VALUES('$descripcion','$talla','$precioalquiler')";

if(mysqli_query($mysqli, $sql)){
    echo '<script language="javascript">';
	echo 'alert("Guardado");';
	echo 'window.location="alquiler.php";';
	echo '</script>';	
}
?>