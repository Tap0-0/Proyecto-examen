<?php

include("config.php");
$id = $_POST['id'];
$DESCRIPCION = $_POST['descripcion'];
$TALLA = $_POST['talla'];
$PRECIO_ALQUILER = $_POST['precio_alquiler'];
$sql = "UPDATE tb_alquiler SET descripcion = '$DESCRIPCION', talla = '$TALLA', precio_alquiler = '$PRECIO_ALQUILER' WHERE id = $id";
if(mysqli_query($mysqli, $sql)){
    echo'<script languaje ="javascript">';
    echo'window.location="alquiler.php"';
    echo'</script>';
}
?>