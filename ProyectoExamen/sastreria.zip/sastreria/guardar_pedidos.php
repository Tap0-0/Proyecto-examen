<?php 
include("config.php");
$tipo_material = $_POST['fechapedido'];
$descripcion = $_POST['fechaentrega'];
$cantidad_disponible = $_POST['total'];

$sql = "INSERT INTO tb_pedidos(fechapedido,fechaentrega,total) 
VALUES('$tipo_material','$descripcion','$cantidad_disponible')";

if(mysqli_query($mysqli, $sql)){
    echo '<script language="javascript">';
	echo 'alert("Guardado");';
	echo 'window.location="pedidos.php";';
	echo '</script>';	
}
?>