<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/mystyle1.css" />
    <title>Ingresar Datos</title>
</head>
<body>
        <<!-- Creamos un menu     -->
        <div class="icon-bar">
    <a href="inicio.php"><i class="fa fa-home"></i></a>
    <a href="clientes.php"><i class="fa fa-user"></i></a>
    </div>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <h2>Clientes</h2>
    <hr>
    <!-- Creo un formulario para ingresar los datos -->
    <form action="guardar_cliente.php" method="POST">
        <div class="container">
            <h1>Nombre</h1>
            <input type="text" name="nombre" required>
            <h1>Apellido</h1>
            <input type="text" name="apellido" requiered>
            <h1>Direccion</h1>
            <input type="text" name="direccion" requiered>
            <h1>Telefono</h1>
            <input type="text" name="telefono" requiered>
            <h1>Correo</h1>
            <input type="text" name="email" requiered>
            <div class="clearfix">
                <button type="submit" class="signupbtn">Guardar</button>
            </div>
        </div>
    </form>
</body>
</html>